﻿using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyCoffeeApp.ViewModels
{
    public class ViewModelBase : BaseViewModel
    {
    }
}
